// =========================
// SANO TECH STORE
// Shopping Cart
// =========================

// Load cart from localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// =========================
// Add Product To Cart
// =========================
function addToCart(productId) {

    const product = window.products.find(item => item.id === productId);

    if (!product) {
        console.error("Product not found:", productId);
        return;
    }

    cart.push(product);

    // Save cart
    localStorage.setItem("cart", JSON.stringify(cart));

    updateCartCount();

    alert(product.name + " added to cart");

    console.log(cart);
}

// =========================
// Update Cart Counter
// =========================
function updateCartCount() {

    const cartCount = document.getElementById("cart-count");

    if (cartCount) {
        cartCount.textContent = cart.length;
    }

}

// =========================
// Clear Cart
// =========================
function clearCart() {

    cart = [];

    localStorage.removeItem("cart");

    updateCartCount();

}

// =========================
// Initialize
// =========================
document.addEventListener("DOMContentLoaded", () => {

    updateCartCount();

});