// =========================
// SANO TECH STORE
// Shop Page
// =========================

function renderProducts(productList = window.products) {

    const container = document.querySelector(".products-grid");

    if (!container) return;

    container.innerHTML = "";

    productList.forEach(product => {

        container.innerHTML += `

        <div class="card product-item">

            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>

            <h3>${product.name}</h3>

            <p>${product.category}</p>

            <p class="price">
                ${formatPrice(product.price)}
            </p>

            <button
                class="btn btn-primary"
                onclick="addToCart(${product.id})">

                Add To Cart

            </button>

        </div>

        `;

    });

}

document.addEventListener("DOMContentLoaded", () => {

    if (window.products) {

        renderProducts();

    }

});