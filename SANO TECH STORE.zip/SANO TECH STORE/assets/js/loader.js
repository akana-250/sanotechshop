// =========================
// SANO TECH STORE
// Component Loader
// =========================

// Menya niba turi muri folder ya pages
const componentPath =
window.location.href.includes("/pages/")
? "../components/"
: "components/";

// Function yo gupakira component
function loadComponent(id, file) {

    const element = document.getElementById(id);

    if (!element) return;

    fetch(componentPath + file)
        .then(response => {

            if (!response.ok) {
                throw new Error(file + " not found");
            }

            return response.text();

        })
        .then(data => {

            element.innerHTML = data;

        })
        .catch(error => {

            console.error(error);

        });

}

// Load Components
loadComponent("announcement","announcement.html");
loadComponent("header","header.html");
loadComponent("hero","hero.html");
loadComponent("categories","categories.html");
loadComponent("featured-products","featured-products.html");
loadComponent("products","products.html");
loadComponent("services","services.html");
loadComponent("footer","footer.html");