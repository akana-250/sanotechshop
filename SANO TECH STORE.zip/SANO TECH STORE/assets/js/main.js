// =========================
// SANO TECH STORE
// Main JavaScript
// =========================

// Announcement
fetch("components/announcement.html")
.then(response => response.text())
.then(data => {
    document.getElementById("announcement").innerHTML = data;
});

// Header
fetch("components/header.html")
.then(response => response.text())
.then(data => {

    document.getElementById("header").innerHTML = data;

    // Update cart counter after header loads
    if (typeof updateCartCount === "function") {
        updateCartCount();
    }

    // Set selected currency
    const currencySelect = document.getElementById("currency-select");

    if (currencySelect) {
        currencySelect.value = currentCurrency;
    }

});

// Hero
fetch("components/hero.html")
.then(response => response.text())
.then(data => {
    document.getElementById("hero").innerHTML = data;
});

// Categories
fetch("components/categories.html")
.then(response => response.text())
.then(data => {
    document.getElementById("categories").innerHTML = data;
});

// Featured Products
fetch("components/featured-products.html")
.then(response => response.text())
.then(data => {
    document.getElementById("featured-products").innerHTML = data;
});

// Products
fetch("components/products.html")
.then(response => response.text())
.then(data => {

    document.getElementById("products").innerHTML = data;

    const productContainer = document.querySelector(".products-grid");

    if (!productContainer || !window.products) return;

    productContainer.innerHTML = "";

    window.products.forEach(product => {

        productContainer.innerHTML += `
            <div class="card product-item">

                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}">
                </div>

                <h3>${product.name}</h3>

                <p>${product.category}</p>

                <p class="price">
                    ${formatPrice(product.price)}
                </p>

                <button
                    class="btn btn-primary"
                    onclick="addToCart(${product.id})">
                    Add To Cart
                </button>

            </div>
        `;

    });

});

// Services
fetch("components/services.html")
.then(response => response.text())
.then(data => {
    document.getElementById("services").innerHTML = data;
});
