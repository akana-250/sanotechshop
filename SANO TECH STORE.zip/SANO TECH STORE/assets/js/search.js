// =========================
// SANO TECH STORE
// Live Search
// =========================

document.addEventListener("DOMContentLoaded", () => {

    const searchInput = document.getElementById("search-input");

    if (!searchInput) return;

    searchInput.addEventListener("keyup", () => {

        const keyword = searchInput.value.toLowerCase();

        const filtered = window.products.filter(product => {

            return (
                product.name.toLowerCase().includes(keyword) ||
                product.category.toLowerCase().includes(keyword)
            );

        });

        if (typeof renderProducts === "function") {
            renderProducts(filtered);
        }

    });

});