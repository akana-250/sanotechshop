// =========================
// SANO TECH STORE
// Cart Page
// =========================

const cartItemsContainer = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");

function renderCart() {

    if (!cartItemsContainer) return;

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    cartItemsContainer.innerHTML = "";

    let total = 0;

    if (cart.length === 0) {

        cartItemsContainer.innerHTML = `
            <p>Your shopping cart is empty.</p>
        `;

        cartTotal.textContent = formatPrice(0);

        return;
    }

    cart.forEach((product, index) => {

        total += product.price;

        cartItemsContainer.innerHTML += `
            <div class="card product-item">

                <img
                    src="${product.image}"
                    alt="${product.name}"
                    width="120">

                <h3>${product.name}</h3>

                <p>${formatPrice(product.price)}</p>

                <button
                    class="btn btn-outline"
                    onclick="removeItem(${index})">

                    Remove

                </button>

            </div>
        `;

    });

    cartTotal.textContent = formatPrice(total);

}

function removeItem(index){

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    cart.splice(index,1);

    localStorage.setItem("cart",JSON.stringify(cart));

    updateCartCount();

    renderCart();

}

document.addEventListener("DOMContentLoaded",renderCart);