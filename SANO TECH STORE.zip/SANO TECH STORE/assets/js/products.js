window.products = [

    {
        id: 1,
        name: "Professional Laptop",
        category: "Computers",
        price: 799000,
        image: "assets/images/products/Laptop.jpg"
    },

    {
        id: 2,
        name: "Smart Smartphone",
        category: "Smartphones",
        price: 499000,
        image: "assets/images/products/phone.jpg"
    },

    {
        id: 3,
        name: "Security Camera",
        category: "Security",
        price: 120000,
        image: "assets/images/products/Camera.jpg"
    }

];