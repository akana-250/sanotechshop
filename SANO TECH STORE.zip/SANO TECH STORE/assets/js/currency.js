// =========================
// SANO TECH STORE
// Currency Manager
// =========================

// Base currency
let currentCurrency = localStorage.getItem("currency") || "RWF";

// Exchange rates (temporary)
// Base = RWF
const exchangeRates = {
    RWF: 1,
    USD: 0.00070,
    EUR: 0.00060,
    GBP: 0.00052,
    KES: 0.090,
    UGX: 2.55,
    TZS: 1.82
};

// Format price
function formatPrice(price) {

    const value = price * exchangeRates[currentCurrency];

    return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency: currentCurrency,
        maximumFractionDigits: 2
    }).format(value);

}

// Change currency
function changeCurrency(currency) {

    currentCurrency = currency;

    localStorage.setItem("currency", currency);

    location.reload();

}